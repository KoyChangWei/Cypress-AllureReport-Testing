describe('Debug Employee Update Page', () => {
  it('should load page and show all form elements', () => {
    cy.visit('http://localhost/proposal-softare%20testing/Hospital-PHP/Hospital-PHP/backend/admin/his_admin_update_single_employee.php?doc_number=5VIFT')
    
    // Take a screenshot to see the page
    cy.screenshot('employee-update-page')
    
    // Check if there are any forms
    cy.get('form').should('exist')
    
    // Log all input elements with their attributes
    cy.get('input').each(($el) => {
      const name = $el.attr('name') || 'no-name'
      const type = $el.attr('type') || 'no-type'
      const id = $el.attr('id') || 'no-id'
      const placeholder = $el.attr('placeholder') || 'no-placeholder'
      cy.log(`Input: name="${name}" type="${type}" id="${id}" placeholder="${placeholder}"`)
    })
    
    // Check for select elements if they exist
    cy.get('body').then(($body) => {
      if ($body.find('select').length > 0) {
        cy.get('select').each(($el) => {
          const name = $el.attr('name') || 'no-name'
          const id = $el.attr('id') || 'no-id'
          cy.log(`Select: name="${name}" id="${id}"`)
        })
      } else {
        cy.log('No select elements found')
      }
    })
    
    // Check for textarea elements if they exist
    cy.get('body').then(($body) => {
      if ($body.find('textarea').length > 0) {
        cy.get('textarea').each(($el) => {
          const name = $el.attr('name') || 'no-name'
          const id = $el.attr('id') || 'no-id'
          cy.log(`Textarea: name="${name}" id="${id}"`)
        })
      } else {
        cy.log('No textarea elements found')
      }
    })
    
    // Print out the form HTML for manual inspection
    cy.get('form').then(($form) => {
      const formHtml = $form.html()
      cy.log('Form HTML length:', formHtml.length)
      // Log first 500 characters to see structure
      cy.log('Form HTML preview:', formHtml.substring(0, 500))
    })
  })
}) 